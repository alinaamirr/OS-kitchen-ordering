#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include "chef.h"
  // Semaphores for each resource

void *chef_work(void *arg) {
	sem_t resources[5];
    int chef_id = (int *)arg;
    int resource_needs[2];  // Stores resource IDs needed by the chef

    // Define resource needs based on the chef's ID (replace with specific requirements)
    switch (chef_id) {
        case 0: resource_needs[0] = 0; resource_needs[1] = 1; break;  // Chef 0: Oven, Large Stove
        case 1: resource_needs[0] = 0; resource_needs[1] = 2; break;  // Chef 1: Large Stove, Small Stove
        case 2: resource_needs[0] = 0; resource_needs[1] = 3; break;  // Chef 2: Small Stove, Mixing Bowl
        case 3: resource_needs[0] = 0; resource_needs[1] = 4; break;  // Chef 3: Mixing Bowl, Blender
        case 4: resource_needs[0] = 4; resource_needs[1] = 0; break;  // Chef 4: Blender, Oven
    case 5: resource_needs[0] = 0; resource_needs[1] = 1; break;  // Chef 5: Blender, Small Stove
    case 6: resource_needs[0] = 1; resource_needs[1] = 2; break;  // Chef 6: Oven, Blender
    case 7: resource_needs[0] = 2; resource_needs[1] = 3; break;  // Chef 7: Mixing Bowl, Large Stove
    case 8: resource_needs[0] = 3; resource_needs[1] = 4; break;  // Chef 8: Small Stove, Oven
    case 9: resource_needs[0] = 4; resource_needs[1] = 0; break;  // Chef 9: Mixing Bowl, Small Stove
    }

    // BUBBLE Sort resource needs to ensure sequential acquisition
    if (resource_needs[0] > resource_needs[1]) {
        int temp = resource_needs[0];	
        resource_needs[0] = resource_needs[1];
        resource_needs[1] = temp;
    }

    for (int i = 0; i < 2; i++) {
        int resource_id = resource_needs[i];  // Acquire resources in sorted order

        // pthread_mutex_lock(&resource_mutex[resource_id]); // Lock the resource

        if (sem_wait(&resources[resource_id]) != 0) {
            perror("Semaphore wait failed");
            return NULL;
        }
      //  pthread_mutex_unlock(&resource_mutex[resource_id]); // Unlock the resource

        printf("Chef %d acquired resource %d\n", chef_id, resource_id);
    }

    printf("Chef %d started Cooking\n",chef_id);
    sleep(2);

    // Release acquired resources
    printf("Chef %d finished Cooking\n",chef_id);
    for (int i = 1; i >= 0; i--) {
        int resource_id = resource_needs[i];
        printf("Chef %d released resource %d\n", chef_id, resource_id);
        if (sem_post(&resources[resource_id]) != 0) {
            perror("Semaphore post failed");
            return NULL;
        }
        
    }

    return NULL;
}
