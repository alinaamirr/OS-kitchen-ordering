void *chef_work(void *arg); 
