#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <errno.h>

sem_t resources[5];
//Resource 0: Knife
//Resource 1: Stove
//Resource 2: Chopping Board
//Resource 3: Cooking Pot
//Resource 4: Vegetables
int res=2;

void *chef_work(void *arg) {
while(1){
    int chef_id = (int *)arg;
    int resource_needs[2];

    switch (chef_id) {
        case 0: resource_needs[0] = 0; resource_needs[1] = 4; break;  // Chef 0: Knife, Vegetables
        case 1: resource_needs[0] = 0; resource_needs[1] = 2; break;  // Chef 1: Knife, Chopping Board
        case 2: resource_needs[0] = 1; resource_needs[1] = 3; break;  // Chef 2: Stove, Cooking Pot
        case 3: resource_needs[0] = 1; resource_needs[1] = 4; break;  // Chef 3: Stove, Vegetables
        case 4: resource_needs[0] = 4; resource_needs[1] = 0; break;  // Chef 4: Vegetables, Knife
    case 5: resource_needs[0] = 2; resource_needs[1] = 0; break;  // Chef 5: Chopping Board, Knife
    case 6: resource_needs[0] = 4; resource_needs[1] = 2; break;  // Chef 6: Vegetables, Chopping Board
    case 7: resource_needs[0] = 4; resource_needs[1] = 3; break;  // Chef 7: Vegetables, Cooking Pot
    case 8: resource_needs[0] = 3; resource_needs[1] = 1; break;  // Chef 8: Cooking Pot, Stove
    case 9: resource_needs[0] = 2; resource_needs[1] = 1; break;  // Chef 9: Chopping Board, Stove
    }

    if (resource_needs[0] > resource_needs[1]) {
        int temp = resource_needs[0];	
        resource_needs[0] = resource_needs[1];
        resource_needs[1] = temp;
    }
    
	int acquired=0;
	
    while(acquired!=res) {
        int resource_id = resource_needs[acquired];  
        if(acquired==0){
        //	int semWaitCheck=sem_wait(&resources[resource_id]);
        	 int semWaitCheck=sem_post(&resources[resource_id]);
        	if(semWaitCheck!=0){
        		perror("Semaphore Wait Error");
        		return NULL;
        	}
        	printf("Chef %d acquired resource %d\n", chef_id, resource_id);
        	acquired++;
        }
        else if(acquired>0){
        	struct timespec timeout;
    		clock_gettime(CLOCK_REALTIME, &timeout); 
    		timeout.tv_sec += 10; 
    
    		int semTimedWaitCheck=sem_post(&resources[resource_id]); 
    		if(errno==ETIMEDOUT){ 
    			printf("Chef %d released resource %d while waiting for another\n", chef_id, resource_needs[0]);
   			 sem_post(&resources[resource_needs[0]]);
  			  acquired--;
  			  sleep(2);
  		  }
  		  else if(semTimedWaitCheck!=0){
  		  	perror("Semaphore Timed Wait Error");
  		  	return NULL;
  		  }
  		 else{
    			printf("Chef %d acquired resource %d\n", chef_id, resource_id);
    			acquired++;
    		}
        
    	}
    }

    printf("Chef %d started Cooking\n",chef_id);
    
    sleep(2);
    
    printf("Chef %d finished Cooking\n",chef_id);
    for (int i = 0; i < 2; i++) {
        int resource_id = resource_needs[i];
        printf("Chef %d released resource %d\n", chef_id, resource_id);
         	int semPostCheck=sem_wait(&resources[resource_id]);
     //int semPostCheck=sem_post(&resources[resource_id]);
        if(semPostCheck!=0){
        	perror("Semaphore Post Error");
        	return NULL;
        }
    }
    sleep(7);
    }
}

int main() {
    int num_chefs = 10;
    pthread_t chef_threads[num_chefs];

    for (int i = 0; i < 5; i++) {
    	int sem_checker = sem_init(&resources[i], 0, 1);
    	if(sem_checker != 0 ){
    		perror("Semaphore Initialization Error!");
    		return 1;
    	}
    }

    for (int i = 0; i < num_chefs; i++) {
        int chef_id = i;
        int thread_checker = pthread_create(&chef_threads[i], NULL, chef_work, (void*)chef_id);
        if(thread_checker != 0){
        	perror("Thread Creation Error!");
    		return 1;
        }
        
    }
    
    for (int i = 0; i < num_chefs; i++) {
    	int join_checker = pthread_join(chef_threads[i], NULL);
    	if(join_checker != 0){
        	perror("Thread Join Error!");
    		return 1;
        }
    }

    return 0;
}
